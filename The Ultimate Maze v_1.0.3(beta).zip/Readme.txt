1st you should download luadroid and ZArchiver. Then open 
ZArchiver and go to downloads folder or wherever you have 
placed the .zip file. Extract it. Then open luadroid. Open game
folder.Open the main.lua file. Tap on the sign with three lines and
then open  console.change the font size to 15. Go back to the game
file and run it. You should see the game working correctly. If the 
maze walls are not in the right place or having problem let me
 know i will fix bugs that are happening. I have seen that in some
phones the game dosen't run properly. 