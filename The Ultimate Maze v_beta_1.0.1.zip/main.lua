function ask(a)
    io.write(a)
    return io.read()
end
function run(a)
    os.execute(a)
end
	
local blocks = {
    { -- l
        " _ _  \n ←u| \n — —  \n",
        {2},
        {3}
    },
    { -- r
        "   _ _\n  |u →\n   — —\n",
        {3},
        {2}
    },
    { -- u
        "  |↑| \n  |u| \n   —  \n",
        {1},
        {4}
    },
    { -- d
        "   _  \n  |u| \n  |↓| \n",
        {4},
        {1}
    },
    { -- lr
        " _ _ _ \n ←u →\n — — —\n",
        {2,3},
        {3,2}
    },
    { -- ud
        "  |↑| \n  |u| \n  |↓| \n",
        {1,4},
        {4,1}
    },
    { -- lru
        " _|↑|_\n ←u →\n — — —\n",
        {2,3,1},
        {3,2,4}
    },
    { -- lrd
        " _ _ _\n ←u →\n —|↓|—\n",
        {2,3,4},
        {3,2,1}
    },
    { -- udl
        " _|↑| \n ←u| \n —|↓| \n",
        {1,4,2},
        {4,1,3}
    },
    { -- udr
        "  |↑|_\n  |u→\n  |↓|—\n",
        {1,4,3},
        {4,1,2}
    },
    { -- a
        "  .↑. \n ←u →\n  .↓.‌‌‌‍‍‍ \n",
        {1,4,2,3},
        {4,1,3,2}
    },
    { -- e
        "  _ _\n |end|\n  _ _\n",
        {},
        {1,2,3,4}
    }
}
local v_blocks = {}
local w_block = {}

local moves = {}
moves["w"] = 1
moves["s"] = 4
moves["a"] = 2
moves["d"] = 3

move = 0

g_end = {
    {5,5},
    {5,-5},
    {-5,5},
    {-5,-5}
}
g_e_n = math.random(1,4)
is_end = false
is_died = false
e = 1

foods = 3
t_f = 3
buff = 1
tiles = 0

cords = {
    x = 0,
    y = 0
}

p = ""
p2 = ""

function cord_updt()
    if moves[move] == 1 then
        cords.y = cords.y + 1
    elseif moves[move] == 4 then
        cords.y = cords.y - 1
    elseif moves[move] == 2 then
        cords.x = cords.x - 1
    elseif moves[move] == 3 then
        cords.x = cords.x + 1
	end
end

function initialize()
	for i = 1,#blocks-1
	do
  	  table.insert(v_blocks,blocks[i])
	end
	local n = math.random(1,#v_blocks)
	w_block = v_blocks[n]
	v_blocks = {}
end

function v_move()
	repeat
	    print("foods : "..foods,"tiles moved : ".. tiles)
	    print("cords : "..cords.x..", "..cords.y)
	    print()
	    print(w_block[1])
  	  print(p)
	    print(p2)
	    p2 = ""
    	ans = ask("")
   	 for i = 1,#w_block[2]
   	 do
   	     if moves[ans] ~=nil and moves[ans] == w_block[2][i] then
   	         move = ans
   	         vldt = 1
   	         p ="you chosed : "..move
   	         cord_updt()
   	         foods = foods - 1
   	         break
   	     elseif (moves[ans] ~= nil and moves[ans]~= w_block[2][i]) or #ans == 1 then
   	         p = "invalid move\nchoose again\n"
   	     else
   	         p = "you didn't chose anything\nplease choose something\n"
   	     end
   	 end
	    run("clear")
	until vldt == 1
end

function add_v_blocks()
	for i = 1,(#blocks - 1)
	do
    	for j = 1,#blocks[i][3]
    	do
    	    if moves[move] == blocks[i][3][j] then
   	         table.insert(v_blocks, blocks[i])
  	      end
 	   end
	end
end

function set_w_block()
    w_block = {}
    r = {
        math.random(1,#v_blocks),
        math.random(1,#v_blocks),
        math.random(1,#v_blocks)
    }
    r4 = math.random(1,3)
    if r[1] == r[2] and r[2] == r[3] then
        w_block = v_blocks[r[1]]
        foods = foods + 50
        t_f = t_f + 50
        p2 = "you got a buffer"
    elseif r[1] == r[2] then
        w_block = v_blocks[r[1]]
        foods = foods + 1
        t_f = t_f + 1
    elseif r2 == r3 then
        w_block = v_blocks[r[2]]
        foods = foods + 1
        t_f = t_f + 1
    elseif r3 == r1 then
        w_block = v_blocks[r[3]]
        foods = foods + 1
        t_f = t_f + 1
    else
        w_block = v_blocks[r[r4]]
    end
    
end

function update()
    vldt = 0
    v_blocks = {}
    move = nil
    tiles = tiles + 1
    foods = foods - 1
    run("clear")
end

function ending()
    if foods <= 0 then
        is_died = true
        is_end = true
    elseif cords.x == g_end[g_e_n][1] and cords.y == g_end[g_e_n][2] then
        is_end = true
        is_died = false
    end
end

function end_scrn()
	local screen = {
    	[[
	 ######################
	    Game	 Over
	 ######################]],
    "	        you died",
    "	     you have won\n	   your score is :"..math.floor((tiles/10*t_f*foods))
	}
    run("clear")
    if foods <= 0 then
        print(screen[1])
        print(screen[2])
    else
        print("	foods : "..foods,"tiles moved : ".. tiles)
        print("	cords : "..cords.x..", "..cords.y)
        print(blocks[#blocks][1])
        ask("")
        run("clear")
        print(screen[1])
        print(screen[3])
        print("...")
        ask("")
        print("Game Name : The Ultimate Maze")
        print("Author        : Kazi Muhtadiul Huda (Rafi)")
        print("programmed by : Kazi Muhtadiul Huda (Rafi)")
        print("Designed by   : Kazi Muhtadiul Huda (Rafi)")
	end
end

function rungame()
    initialize()
    repeat
        v_move()
        add_v_blocks()
        set_w_block()
        update()
        ending()
    until is_end or is_died
    end_scrn()
end

rungame()

